/**
 Provides a pluggable service provider interface, which allows the HTTP server
 implementation to be replaced with other implementations.
*/
package com.sun.net.httpserver.spi;
