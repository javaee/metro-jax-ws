package testutil.benchmark;

import java.util.Arrays;

/**
 * @author Kohsuke Kawaguchi
 */
final class Util {
    static byte[] fillArray(byte[] data) {
        Arrays.fill(data, (byte) 85);
        return data;
    }
}
