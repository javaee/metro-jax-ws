package testutil.benchmark;

/**
 * Implemented by the benchmark unit tests
 *
 * @author Arun Gupta
 */
public interface Benchmark {
    /**
     * Runs the test.
     */
    public void testOnce() throws Exception;
}
